package mapObjects;

import mapUtilities.Cell;
import mapUtilities.MapObject;
/**
 * 
 * @author Artir2d2
 *
 */
public class Building extends MapObject{

	@Override
	public void placeObject(Cell cell) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeObject(Cell cell) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void interact(Character character, String arg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
