package mapObjects;

import mapUtilities.MapObject;

public interface ExistListener {
	void existChanged(MapObject initiator);
}
