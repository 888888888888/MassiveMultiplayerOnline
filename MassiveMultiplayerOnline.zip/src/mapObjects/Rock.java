package mapObjects;

public class Rock {

}
