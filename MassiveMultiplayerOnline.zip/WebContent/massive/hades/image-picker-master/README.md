# Image Picker

Image Picker is a simple jQuery plugin that transforms a select element into a more user friendly graphical interface.

# Installation

Just download the latest build and add the corresponding .js and .css to your assets directory

# Examples and doc

Visit http://rvera.github.com/image-picker
